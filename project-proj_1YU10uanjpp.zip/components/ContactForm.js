function ContactForm() {
  try {
    const [formData, setFormData] = React.useState({
      name: '',
      email: '',
      phone: '',
      message: ''
    });
    const [status, setStatus] = React.useState('');

    const handleSubmit = async (e) => {
      e.preventDefault();
      setStatus('sending');
      
      try {
        const submissionData = {
          Name: formData.name,
          Email: formData.email,
          Phone: formData.phone,
          Message: formData.message,
          Status: 'Novo',
          SubmittedAt: new Date().toISOString()
        };
        
        await trickleCreateObject('contact_submission', submissionData);
        
        setStatus('success');
        setFormData({ name: '', email: '', phone: '', message: '' });
        setTimeout(() => setStatus(''), 3000);
      } catch (error) {
        console.error('Error saving contact submission:', error);
        setStatus('error');
        setTimeout(() => setStatus(''), 3000);
      }
    };

    const handleChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
      <section id="contato" className="py-16 bg-[var(--bg-light)]" data-name="contact-form" data-file="components/ContactForm.js">
        <div className="container mx-auto px-4">
          <h2 className="section-title">Entre em Contato</h2>
          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-md">
              <div className="mb-4">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Nome</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
                />
              </div>
              <div className="mb-4">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">E-mail</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
                />
              </div>
              <div className="mb-4">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Telefone</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
                />
              </div>
              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Mensagem</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows="4"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
                ></textarea>
              </div>
              <button type="submit" className="btn-primary w-full" disabled={status === 'sending'}>
                {status === 'sending' ? 'Enviando...' : 'Enviar Mensagem'}
              </button>
              {status === 'success' && (
                <div className="mt-4 p-4 bg-green-100 text-green-700 rounded-lg">
                  Mensagem enviada com sucesso! Entraremos em contato em breve.
                </div>
              )}
              {status === 'error' && (
                <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
                  Erro ao enviar mensagem. Por favor, tente novamente.
                </div>
              )}
            </form>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('ContactForm component error:', error);
    return null;
  }
}